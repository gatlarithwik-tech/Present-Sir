# PresentSir: AttendAlert

A static frontend web application for university attendance tracking, early-warning risk classification, recovery projection, and proactive student mentoring.

## Features
- **Mentor & Early-Warning Hub**: Real-time Critical Shortage (<65%) alert banner, KPI summary cards, filterable 30-student roster, student inspection drawer, closed-form recovery calculator (`ceil((0.75 * Total - Attended) / 0.25)`), automated email alert simulator, and mentoring intervention log.
- **Faculty Attendance Marking Sheet**: Pre-selected Present roster for rapid class entry, Mark All Present / Invert toggles, live before/after risk previews, and Biometric CSV Importer.
- **Student Self-Service Portal**: Individual student dashboard with subject-wise progress bars, 75% threshold markers, consecutive recovery targets, and safe skip margins.
- **Analytics & Medical Exemptions**: Interactive HTML5 Canvas Attendance vs. Midterm Marks scatter plot with Pearson correlation ($r$) and a Medical Leave Exemption workflow.

## How to Run
Simply open `index.html` in any modern web browser (no backend server or build step required).
